<?php 	

function summa($a,$b,$c)
{
	return $a+$b+$c;
}

function random()
{
	$mass=[];
	for ($i=0; $i <10 ; $i++) { 
		$mass[] = rand(1,100);
	}
	return $mass;
}
function minus1($m1,$m2)
{
	foreach ($m1 as $mm1) {
		foreach ($m2 as $key => $mm2) {
			if  ($mm1 == $mm2)
				unset($m2[$key]);
		}
	}
	return $m2;
}

function masss($z,$x)
{
	$mass=[];
	for ($i=0; $i < $z; $i++) { 
		for ($j=0; $j < $x; $j++) { 
			$mass[$i][$j]=rand(1,100);
		}
	}
	return $mass;
}

?>