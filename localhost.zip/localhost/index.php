<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
require ('function.php');
$a=5;
$b=6;
$c=1;

echo '<br>1. ';
foreach (random() as $mas) {
	echo $mas;
	echo ' ';
}

$mass1 = [
	'1',
	'2',
	'3',

];

$mass2 = [
	'1',
	'2',
	'4',
	'5'
];
echo '<br>2. ';
foreach (minus1($mass1,$mass2) as $value) {
	echo $value;
	echo " ";
}

echo '<br>3. ';
echo '5+6+1=';
echo summa($a,$b,$c);


echo '<br>4. ';

$z = 3;
$x = 3;

echo "<pre>";
foreach (masss($z,$x) as $values) {
	foreach ($values as $value) {
		echo $value;
		echo " ";
	}
	echo "<br>";
}
?>

<form method="post" class="calculate-form">
    <input type="text" name="number1" class="numbers" placeholder="Первое число"> <!-- поле для ввода первого числа -->
    <select  name="operation"> <!-- список с операндами -->
        <option value='plus'>+ </option>
        <option value='minus'>- </option>
        <option value="multiply">* </option>
        <option value="divide">/ </option>
    </select>
    <input type="text" name="number2" class="numbers" placeholder="Второе число"> <!-- поле для ввода второго числа -->

    <input  type="submit" name="submit" value="Получить ответ"> <!-- кнопка -->
</form>
</body>
</html>
<?php

if(isset($_POST['submit'])) {
    $number1 = $_POST['number1'];
    $number2 = $_POST['number2'];
    $operation = $_POST['operation'];

    switch ($operation) {
        case 'plus':
            $result = $number1 + $number2;
            break;
        case 'minus':
            $result = $number1 - $number2;
            break;
        case 'multiply':
            $result = $number1 * $number2;
            break;
        case 'divide':
            if ($number2 == '0')
                $error_result = "На ноль делить нельзя!";
            else
                $result = $number1 / $number2;
            break;
    }
    echo "<div>Ответ: $result</div>";
}?>